/**
 * 
 */
package rmibankaccount.common;

import java.rmi.*;
/**
 * @author Rubaya
 *
 */
//ITransaction.java
//Interface for the RMI remote object.
//Note:  Interface must extend from java.rmi.Remote
//Methods must throw RemoteExcpetion
//This interface has two methods - withdraw and deposit


public interface ITransaction extends Remote {

	//Calculation for money withdrawing
	public Money withdraw(Money balance) throws RemoteException;
	//Calculation for money depositing
	public Money deposit(Money balance) throws RemoteException;
}
