/**
 * 
 */
package rmibankaccount.common;

/**
 * @author Rubaya
 *
 */
// class Money indicates a type of balance attribute
public class Money implements java.io.Serializable {
	
	public double amount;
	
	public Money(double balance) {
		this.amount = balance;
	}
}

