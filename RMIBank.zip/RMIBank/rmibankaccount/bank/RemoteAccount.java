/**
 * 
 */
package rmibankaccount.bank;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * @author Rubaya
 *
 */
//RemoteAccount.java
//Java server application
//Create an object of the interface  
//implementation class
//rmiregistry within the server JVM with  
//port number 2028
//Binds the remote object by the name "rmibank"
public class RemoteAccount {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			// create an instance of the service object
			AccountImpl account = new AccountImpl();
			// Taking the host name of the remote object
			String host = args[0];
			// taking the port number
			int port = Integer.parseInt(args[1]);
			
			String name="//"+host+":"+port+"/rmibank";
			//String name = "//localhost/RemoteAccount";
			// Binding the remote object (account) in the registry 
			Registry registry = LocateRegistry.getRegistry(port);
			registry.rebind(name, account);
			
			//Naming.rebind(name, account);
			System.out.println("Server connection Established with "+name);
		}
		catch(Exception e) {
			e.printStackTrace();
			//System.out.println("Error while establishing the server");
		}
	}

}
