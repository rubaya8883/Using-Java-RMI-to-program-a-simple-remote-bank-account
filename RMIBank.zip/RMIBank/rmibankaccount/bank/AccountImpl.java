/**
 * 
 */
package rmibankaccount.bank;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import rmibankaccount.common.ITransaction;
import rmibankaccount.common.Money;

/**
 * @author Rubaya
 *
 */
//AccountImpl.java
//Implementing the remote interface
//Note: The object must extend from UnicastRemoteObject
//The object must implement the associated interface ITransaction

public class AccountImpl extends UnicastRemoteObject implements ITransaction {
	
	private String name;
	private Money balance= new Money(5000);
	
	public AccountImpl() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public Money withdraw(Money amnt) throws RemoteException {
		// TODO Auto-generated method stub
		Money newBalance = new Money(balance.amount - amnt.amount);
//		newBalance = balance.amount - amnt.amount;
		System.out.println("Money withdrawn successfully. New account balance is: "+newBalance);
		return newBalance;
	}

	@Override
	public Money deposit(Money amnt) throws RemoteException {
		// TODO Auto-generated method stub
		Money newBalance = new Money(balance.amount + amnt.amount);
//		newBalance = balance.amount - amnt.amount;
		System.out.println("Money depositted successfully. New account balance is: "+newBalance);
		return newBalance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Money getBalance() {
		return balance;
	}

	public void setBalance(Money balance) {
		this.balance = balance;
	}

}
