/**
 * 
 */
package rmibankaccount.client;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

import rmibankaccount.bank.AccountImpl;
import rmibankaccount.common.ITransaction;
import rmibankaccount.common.Money;

/**
 * @author Rubaya
 *
 */
//Client.java
//Java rmi client application
//It is fetching the remote object and invoking its methods

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			
			String host = args[0];
			int port = Integer.parseInt(args[1]);
			
			
			String name="//"+host+":"+port+"/rmibank";
			// Getting the registry 
			Registry registry = LocateRegistry.getRegistry(host,port);
			
			//String name = "//localhost/RemoteAccount";
			AccountImpl account = new AccountImpl();
			account.setName("John Raymond");
			
			// Looking up the registry for the remote object 
			//ITransaction transaction = (ITransaction)Naming.lookup(name);
			ITransaction transaction = (ITransaction)registry.lookup(name);
			
			Money amnt = new Money(5000);
			//showing account balance
			System.out.println("Account balance of "+account.getName()+" is "+amnt.amount);
			System.out.println("Choose Operation- 1. Withdraw    2. Deposit ");
			
			Scanner scanner = new Scanner(System.in);
			Integer operation = scanner.nextInt();
			
			switch (operation) {
			case 1:
				System.out.println("Withdraw amount:");
				double withdrawamnt = scanner.nextDouble();
				
				Money m1 = new Money(withdrawamnt);
				Money m2 = transaction.withdraw(m1);
				System.out.println("Available Balance: "+m2.amount);
				break;
			case 2:
				System.out.println("Deposit amount:");
				double depositamnt = scanner.nextDouble();
				
				Money m3 = new Money(depositamnt);
				Money m4 = transaction.deposit(m3);
				
				System.out.println("Available Balance: "+m4.amount);
				break;
				
			default : 
				System.out.println("Invalid Operation, Please try again");
			
			}
			
		}
		catch(Exception e){
			System.out.println("Error Occoured");
		}
	}

}
