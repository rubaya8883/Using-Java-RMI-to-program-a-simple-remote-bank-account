Commands needed to run the RMI Example-

1.ssh username@tesla.cs.uni.edu

2.create a folder with any name ( for example- "oodp")
command - mkdir oodp

3. To change directory permissions-
chmod +rwx filename to add permissions. ( here filename -oodp )

4. copy the rmibankaccount folder to the tesla machine inside the folder named oodp

5. Change the file permission using the command in step 3

6. You can use the following machines for RMI :
in-csci-rrpc01.cs.uni.edu
in-csci-rrpc02.cs.uni.edu
in-csci-rrpc03.cs.uni.edu
in-csci-rrpc04.cs.uni.edu
in-csci-rrpc05.cs.uni.edu
in-csci-rrpc06.cs.uni.edu

For example-
ssh in-csci-rrpc01.cs.uni.edu

7. enter into the folder- oodp as example, where rmibankaccount were kept
  cd oodp/ 
8. ps eaf | grep rmiregistry

9. Check the port id, which will be given to run, ( as example- 2021 ).
if rmiregistry job is running, kill it : kill -9 <pid>

10. if the port is - 2021 then 
rmiregistry 2021 &

11. To run the server-
java rmibankaccount/bank/RemoteAccount in-csci-rrpc01.cs.uni.edu 2021

 For running the client-

12. # In a different machine: ( To run the client )
(please open another terminal and run command - ssh username@tesla.cs.uni.edu)
for example-
ssh in-csci-rrpc02.cs.uni.edu

13. cd oodp/

14. java rmibankaccount/client/Client in-csci-rrpc01.cs.uni.edu 2021


